<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


$api = app('Dingo\Api\Routing\Router');

$api->version('v1', function($api){
	$api->post('search','App\Http\Controllers\SearchController@search');
});

$api->version('v1', function($api){
	$api->post('private','App\Http\Controllers\SearchController@private');
});

$api->version('v1', function($api){
	$api->post('bulk','App\Http\Controllers\SearchController@bulk');
});

$api->version('v1', function($api){
	$api->post('register','App\Http\Controllers\RegisterController@register');
});

$api->version('v1', function($api){
	$api->post('verify','App\Http\Controllers\RegisterController@verify');
});

$api->version('v1', function($api){
	$api->post('valid','App\Http\Controllers\RegisterController@valid');
});

$api->version('v1', function($api){
	$api->post('login','App\Http\Controllers\RegisterController@login');
});