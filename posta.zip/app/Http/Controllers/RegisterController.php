<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;

class RegisterController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public $phone = "hi";

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    
    public function verify(Request $request){
        $phone = $request->input('phone');

        if(strlen($phone) < 1){
            return response(array(
                "message" => "Please enter number to verify",
                "code" => 209,
                "status" => "No content",
                ));
        }
        else if((strlen($phone) < 10) || (strlen($phone) > 13)){
             return response(array(
                "message" => "Please enter a valid phone number",
                "code" => 209,
                "status" => "Fail",
                ));
        } 
        else if((strlen($phone) > 9) || (strlen($phone) < 14)){
            $code = rand ( 10000 , 99999 );
            $this->send($phone, $code);
            $current = time();
            $delete = $current+1;
            DB::table('codes')->insert(['phone'=>$phone, 'code'=>$code, 'created_at'=>$current, 'delete' => $delete]);
           // $codes = DB::table('codes')->where(('delete' - 'current' = 1))->delete();
            
             return response(array(
                "message" => $phone,
                "code" => $code,
                "status" => "Success",
                ));
         
        }
        
    }

    public function valid(Request $request){
             $phoneNum = $request->input('phone');
             $codeNum = $request->input('code');
             $codes = DB::table('codes')->where(['phone'=>$phoneNum, 'code'=>$codeNum])->get();
             if(count($codes) > 0){
                return response(array(
                "message" => "You have entered the right code",
                "code" => 200,
                "status" => "Success",
                ));
            }else{
             return response(array(
                "message" => "Please enter the code that was sent to you",
                "code" => 200,
                "status" => "Success",
                ));
         }
    }

   public function send($phone, $code){
                     if(strlen($phone) == 10){
                           $newNum = ltrim($phone, "0");
                           $numUse = "+254". $newNum;

                            $parameters = array(
                            "from" => "Uwazii", "to" => $numUse, "text" => $code);
                            $jsonString = json_encode($parameters);
                            $ip = "107.20.199.106";
                            $url = "http://$ip/restapi/sms/1/text/single";

                            $curl = curl_init($url);
                            curl_setopt($curl, CURLOPT_HEADER, false);
                            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt(
                            $curl, CURLOPT_HTTPHEADER,
                            array(
                            "Host: $ip",
                            "Authorization: Basic TW9DaGFuZ2U6MG52dnZiR2M=",
                            "Accept: application/json",
                            "Content-type: application/json")
                            );
                            curl_setopt($curl, CURLOPT_POST, true);
                            curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonString);


                            $jsonResponse = curl_exec($curl);

                            // Close connection
                            curl_close($curl);
                            //echo '<pre>'; print_r($jsonResponse);echo '<br>';
                            $resultsArray = json_decode($jsonResponse, true);

                           // print_r($resultsArray, true);
              }else{
                      $parameters = array(
                            "from" => "Uwazii", "to" => $phone, "text" => $code);
                            $jsonString = json_encode($parameters);
                            $ip = "107.20.199.106";
                            $url = "http://$ip/restapi/sms/1/text/single";

                            $curl = curl_init($url);
                            curl_setopt($curl, CURLOPT_HEADER, false);
                            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt(
                            $curl, CURLOPT_HTTPHEADER,
                            array(
                            "Host: $ip",
                            "Authorization: Basic TW9DaGFuZ2U6MG52dnZiR2M=",
                            "Accept: application/json",
                            "Content-type: application/json")
                            );
                            curl_setopt($curl, CURLOPT_POST, true);
                            curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonString);


                            $jsonResponse = curl_exec($curl);

                            // Close connection
                            curl_close($curl);
                            //echo '<pre>'; print_r($jsonResponse);echo '<br>';
                            $resultsArray = json_decode($jsonResponse, true);

                            //print_r($resultsArray, true);
                       
              }
             
    }

    public function register(Request $request)
    {
        $firstName = $request->input('firstName');
        $lastName = $request->input('lastName');
        $phone = $request->input('phone');
        $email = $request->input('email');
        $password = $request->input('password');
        $password2 = $request->input('password2');
        if(strlen($firstName) < 1){
            return response(array(
                "Message" => "Please enter your first name",
                "code" => 209,
                "status" => "Fail",
             ));
        }else if(strlen($lastName) < 1){
            return response(array(
                "Message" => "Please enter your last name",
                "code" => 209,
                "status" => "Fail",
             ));
        }else if(strlen($phone) < 10 || strlen($phone) > 13 ){
            return response(array(
                "Message" => "Please enter a valid phone number",
                "code" => 209,
                "status" => "Fail",
             ));
        }else if(filter_var($email, FILTER_VALIDATE_EMAIL) === false ){
            return response(array(
                "Message" => "Please enter a valid Email",
                "code" => 209,
                "status" => "Fail",
             ));
        }else if(strcmp($password, $password2) ){
            return response(array(
                "Message" => "Your passwords dont match",
                "code" => 209,
                "status" => "Fail",
             ));
        }else{
            $users = DB::table('members')->insert(['FirstName' => $firstName, 'LastName' => $lastName, 'Phone' => $phone, 'Email' => $email, 'Password' => $password]);
            if($users){
            return response(array(
                    "message" => "Registration successful",
                    "code" => 200,
                    "status" => "success",
                ));
            }else{
            return response(array(
                    "message" => "Registration failed",
                    "code" => 500,
                    "status" => "fail",
                    ));
            }
        }
    }

     public function login(Request $request){
                    $email = $request->input('email');
                    $password = $request->input('password');

                    $checkLogin = DB::table('members')->where(['Email'=>$email, 'Password'=>$password])->get();
                    if(count($checkLogin) > 0){
                        
                        $members = DB::table('members')->select('FirstName', 'Phone', 'Password')->where(['Email'=>$email])->get();
                        session_start();
                        foreach ($members as $member)
                            {
                                $_SESSION['FirstName'] = $member->FirstName;
                            }
                        return response(array(
                            'message' => 'Log in successful',
                            'value' => $_SESSION['FirstName'],
                           ),200);
                    }else{
                        return response(array(
                            "message" => "Authentication failed, details provided are invalid"));
                        
                    }

        }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
